<?php
include 'koneksi.php';
$transaksi_id = isset($_GET['id']) ? (int)$_GET['id'] : 1;
$master = mysqli_fetch_assoc(
    mysqli_query(
        $koneksi,
        "SELECT t.*, p.nama AS nama_pelanggan 
         FROM transaksi t 
         JOIN pelanggan p ON p.id = t.pelanggan_id 
         WHERE t.id = $transaksi_id"
    )
);
$notif = isset($_GET['notif']) ? $_GET['notif'] : '';
?>
<!DOCTYPE html>
<html>
<head>
    <title>Master Detail</title>
    <style>
        body { font-family: Arial; padding: 20px; }
        table { border-collapse: collapse; width: 100%; }
        th, td { border: 1px solid #ccc; padding: 8px; }
        th { background: #eee; }
        .box { border: 1px solid #ddd; padding: 15px; margin-bottom: 15px; border-radius: 8px; }
        input, select, button { padding: 8px; }
    </style>
</head>
<body>
    <h2>Master - Detail Transaksi (No. 2)</h2>
    <p><a href="barang.php">Ke Halaman Barang (No. 3)</a></p>
    <?php if ($notif): ?>
        <p><b><?= $notif ?></b></p>
    <?php endif; ?>
    <div class="box">
        <h3>Pilih Master Transaksi</h3>
        <form method="GET">
            <select name="id" onchange="this.form.submit()">
                <?php
                $q = mysqli_query(
                    $koneksi,
                    "SELECT t.*, p.nama 
                     FROM transaksi t 
                     JOIN pelanggan p ON p.id = t.pelanggan_id 
                     ORDER BY t.id"
                );
                while ($t = mysqli_fetch_assoc($q)) {
                    $sel = ($t['id'] == $transaksi_id) ? 'selected' : '';
                    echo "<option value='{$t['id']}' $sel>
                            Transaksi #{$t['id']} - {$t['nama']} - Total Rp {$t['total']}
                          </option>";
                }
                ?>
            </select>
        </form>
        <form action="tambah_transaksi.php" method="POST" style="margin-top: 10px;">
            Buat Baru:
            <select name="pelanggan_id">
                <?php
                $p = mysqli_query($koneksi, "SELECT * FROM pelanggan");
                while ($r = mysqli_fetch_assoc($p)) {
                    echo "<option value='{$r['id']}'>{$r['nama']}</option>";
                }
                ?>
            </select>
            <button>+ Buat Transaksi Baru</button>
        </form>
    </div>
    <?php if ($master): ?>
        <div class="box">
            <h3>
                Detail Transaksi #<?= $master['id'] ?> -
                <?= $master['nama_pelanggan'] ?> -
                Total: Rp <?= number_format($master['total']) ?>
            </h3>
            <table>
                <tr>
                    <th>Barang</th>
                    <th>Harga</th>
                    <th>Qty</th>
                    <th>Subtotal</th>
                    <th>Aksi</th>
                </tr>
                <?php
                $d = mysqli_query(
                    $koneksi,
                    "SELECT d.*, b.nama_barang 
                     FROM transaksi_detail d 
                     JOIN barang b ON b.id = d.barang_id 
                     WHERE d.transaksi_id = $transaksi_id"
                );

                if (mysqli_num_rows($d) == 0) {
                    echo "<tr><td colspan='5'>Belum ada detail</td></tr>";
                }

                while ($r = mysqli_fetch_assoc($d)) {
                    echo "<tr>
                            <td>{$r['nama_barang']}</td>
                            <td>" . number_format($r['harga']) . "</td>
                            <td>{$r['qty']}</td>
                            <td>" . number_format($r['harga'] * $r['qty']) . "</td>
                            <td>
                                <a href='hapus_detail.php?transaksi_id=$transaksi_id&barang_id={$r['barang_id']}' 
                                   onclick=\"return confirm('Hapus detail ini?')\">
                                    <button type='button'>Delete</button>
                                </a>
                            </td>
                          </tr>";
                }
                ?>
            </table>
            <h4>Tambah Detail (No. 4)</h4>
            <form action="tambah_detail.php" method="POST">
                <input type="hidden" name="transaksi_id" value="<?= $transaksi_id ?>">
                <select name="barang_id" required>
                    <option value="">-- Pilih Barang --</option>
                    <?php
                    $q = mysqli_query(
                        $koneksi,
                        "SELECT * FROM barang 
                         WHERE id NOT IN (
                            SELECT barang_id 
                            FROM transaksi_detail 
                            WHERE transaksi_id = $transaksi_id
                         )"
                    );
                    while ($br = mysqli_fetch_assoc($q)) {
                        echo "<option value='{$br['id']}'>
                                {$br['nama_barang']} - Rp " . number_format($br['harga']) . "
                              </option>";
                    }
                    ?>
                </select>
                <input type="number" name="qty" placeholder="Qty" min="1" required>
                <button>Tambah Detail</button>
            </form>
            <p><i>Barang yang sudah dipilih tidak muncul lagi di dropdown.</i></p>
        </div>
    <?php endif; ?>

</body>
</html>