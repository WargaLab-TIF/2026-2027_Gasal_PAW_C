<?php
include 'koneksi.php';
$id = (int)$_GET['id'];
$cek = mysqli_query($koneksi, "SELECT * FROM transaksi_detail WHERE barang_id=$id");
if (mysqli_num_rows($cek) > 0) {
    header("Location: barang.php?notif=GAGAL! Barang masih digunakan pada transaksi, tidak bisa dihapus!");
} else {
    mysqli_query($koneksi, "DELETE FROM barang WHERE id=$id");
    header("Location: barang.php?notif=Barang berhasil dihapus!");
}
exit;
?>