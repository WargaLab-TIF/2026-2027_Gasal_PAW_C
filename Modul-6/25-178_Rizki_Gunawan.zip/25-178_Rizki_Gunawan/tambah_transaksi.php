<?php
include 'koneksi.php';
$pelanggan_id = $_POST['pelanggan_id'];
$waktu = date('Y-m-d');
mysqli_query($koneksi, "INSERT INTO transaksi (waktu_transaksi, keterangan, total, pelanggan_id) VALUES ('$waktu','Transaksi Baru',0,'$pelanggan_id')");
$new_id = mysqli_insert_id($koneksi);
header("Location: index.php?id=$new_id");
exit;
?>