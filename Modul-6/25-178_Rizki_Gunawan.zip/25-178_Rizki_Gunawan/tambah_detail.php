<?php
include 'koneksi.php';
$transaksi_id = (int)$_POST['transaksi_id'];
$barang_id    = (int)$_POST['barang_id'];
$qty          = (int)$_POST['qty'];
$b = mysqli_fetch_assoc(
    mysqli_query($koneksi, "SELECT harga FROM barang WHERE id = $barang_id")
);
$harga = $b['harga'];
mysqli_query(
    $koneksi,
    "INSERT INTO transaksi_detail VALUES ($transaksi_id, $barang_id, $harga, $qty)"
);
$s = mysqli_fetch_assoc(
    mysqli_query(
        $koneksi,
        "SELECT SUM(harga * qty) AS total 
         FROM transaksi_detail 
         WHERE transaksi_id = $transaksi_id"
    )
);
$total_baru = $s['total'] ?? 0;
mysqli_query(
    $koneksi,
    "UPDATE transaksi SET total = $total_baru WHERE id = $transaksi_id"
);
header("Location: index.php?id=$transaksi_id&notif=Detail berhasil ditambah, total otomatis terupdate!");
exit;
?>