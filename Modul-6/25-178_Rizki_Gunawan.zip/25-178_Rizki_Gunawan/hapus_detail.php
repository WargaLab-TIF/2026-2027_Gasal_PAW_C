<?php
include 'koneksi.php';
$transaksi_id = (int)$_GET['transaksi_id'];
$barang_id = (int)$_GET['barang_id'];
mysqli_query($koneksi, "DELETE FROM transaksi_detail WHERE transaksi_id=$transaksi_id AND barang_id=$barang_id");
$s = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT SUM(harga*qty) as total FROM transaksi_detail WHERE transaksi_id=$transaksi_id"));
$total_baru = $s['total'] ?? 0;
mysqli_query($koneksi, "UPDATE transaksi SET total=$total_baru WHERE id=$transaksi_id");
header("Location: index.php?id=$transaksi_id&notif=Detail berhasil dihapus!");
exit;
?>