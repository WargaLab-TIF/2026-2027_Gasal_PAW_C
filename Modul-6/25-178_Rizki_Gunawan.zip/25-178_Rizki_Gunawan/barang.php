<?php
include 'koneksi.php';
$notif = isset($_GET['notif']) ? $_GET['notif'] : '';
?>
<!DOCTYPE html>
<html>
<head>
    <title>Barang</title>
    <style>
        body { font-family: Arial; padding: 20px; }
        table { border-collapse: collapse; width: 100%; }
        th, td { border: 1px solid #ccc; padding: 8px; }
        th { background: #eee; }
    </style>
</head>
<body>
    <h2>Data Barang (No. 3)</h2>
    <p><a href="index.php">Kembali ke Transaksi</a></p>
    <?php if ($notif): ?>
        <p><b><?= $notif ?></b></p>
    <?php endif; ?>
    <table>
        <tr>
            <th>ID</th>
            <th>Kode</th>
            <th>Nama</th>
            <th>Harga</th>
            <th>Stok</th>
            <th>Aksi</th>
        </tr>
        <?php
        $q = mysqli_query($koneksi, "SELECT * FROM barang");
        while ($b = mysqli_fetch_assoc($q)) {
            echo "<tr>
                    <td>{$b['id']}</td>
                    <td>{$b['kode_barang']}</td>
                    <td>{$b['nama_barang']}</td>
                    <td>" . number_format($b['harga']) . "</td>
                    <td>{$b['stok']}</td>
                    <td>
                        <a href='hapus_barang.php?id={$b['id']}' 
                           onclick=\"return confirm('Yakin hapus {$b['nama_barang']}?')\">
                            <button type='button'>Delete</button>
                        </a>
                    </td>
                  </tr>";
        }
        ?>
    </table>
</body>
</html>