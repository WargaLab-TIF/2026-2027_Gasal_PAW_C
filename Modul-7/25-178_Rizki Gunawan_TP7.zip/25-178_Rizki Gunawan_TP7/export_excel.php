<?php
include 'koneksi.php';
$tanggal_mulai = $_GET['tanggal_mulai'];
$tanggal_selesai = $_GET['tanggal_selesai'];
$query = "SELECT waktu_transaksi, SUM(total) AS total_pendapatan
          FROM transaksi
          WHERE waktu_transaksi BETWEEN '$tanggal_mulai' AND '$tanggal_selesai'
          GROUP BY waktu_transaksi
          ORDER BY waktu_transaksi ASC";
$result = mysqli_query($koneksi, $query);
header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=laporan_penjualan.xls");
echo "<table border='1'>";
echo "<tr>
        <th>No</th>
        <th>Total Pendapatan</th>
        <th>Tanggal Transaksi</th>
      </tr>";
$no = 1;
while ($row = mysqli_fetch_assoc($result)) {
    echo "<tr>";
    echo "<td>" . $no++ . "</td>";
    echo "<td>" . $row['total_pendapatan'] . "</td>";
    echo "<td>" . $row['waktu_transaksi'] . "</td>";
    echo "</tr>";
}
echo "</table>";
?>