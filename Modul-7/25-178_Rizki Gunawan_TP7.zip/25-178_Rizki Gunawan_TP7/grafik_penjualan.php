<?php
include 'koneksi.php';
$tanggal_mulai = $_GET['tanggal_mulai'] ?? '';
$tanggal_selesai = $_GET['tanggal_selesai'] ?? '';
$tanggal = [];
$pendapatan = [];
if ($tanggal_mulai != '' && $tanggal_selesai != '') {
    $query = "SELECT
                waktu_transaksi,
                SUM(total) AS total_pendapatan
              FROM transaksi
              WHERE waktu_transaksi BETWEEN ? AND ?
              GROUP BY waktu_transaksi
              ORDER BY waktu_transaksi ASC";
    $stmt = mysqli_prepare($koneksi, $query);
    mysqli_stmt_bind_param(
        $stmt,
        "ss",
        $tanggal_mulai,
        $tanggal_selesai
    );
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    while ($row = mysqli_fetch_assoc($result)) {
        $tanggal[] = date(
            'd-m-Y',
            strtotime($row['waktu_transaksi'])
        );
        $pendapatan[] = (int) $row['total_pendapatan'];
    }
    mysqli_stmt_close($stmt);
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Grafik Penjualan</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f6f9;
            padding: 30px;
        }
        .container {
            max-width: 900px;
            margin: auto;
        }
        .card {
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            margin-top: 20px;
        }
        h2 {
            color: #1e3a5f;
        }
        input {
            padding: 10px;
            margin: 5px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        button {
            padding: 11px 18px;
            background-color: #2563eb;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .grafik {
            position: relative;
            height: 400px;
        }
    </style>
</head>
<body>
<div class="container">
    <h2>Grafik Laporan Penjualan</h2>
    <div class="card">
        <form method="GET" action="">
            <label>Tanggal Mulai:</label>
            <input
                type="date"
                name="tanggal_mulai"
                value="<?php echo htmlspecialchars($tanggal_mulai); ?>"
                required
            >
            <label>Tanggal Selesai:</label>
            <input
                type="date"
                name="tanggal_selesai"
                value="<?php echo htmlspecialchars($tanggal_selesai); ?>"
                required
            >
            <button type="submit">
                Tampilkan
            </button>
        </form>
    </div>
    <div class="card">
        <h3>Grafik Total Pendapatan Per Hari</h3>
        <?php if ($tanggal_mulai != '' && $tanggal_selesai != ''): ?>
            <?php if (count($tanggal) > 0): ?>
                <div class="grafik">
                    <canvas id="grafikPenjualan"></canvas>
                </div>
            <?php else: ?>
                <p>Tidak ada transaksi pada rentang tanggal tersebut.</p>
            <?php endif; ?>
        <?php else: ?>
            <p>Silakan pilih tanggal mulai dan tanggal selesai.</p>
        <?php endif; ?>
    </div>
</div>
<?php if (count($tanggal) > 0): ?>
<script>
    const tanggal = <?php echo json_encode($tanggal); ?>;
    const pendapatan = <?php echo json_encode($pendapatan); ?>;
    const ctx = document.getElementById('grafikPenjualan');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: tanggal,
            datasets: [{
                label: 'Total Pendapatan (Rp)',
                data: pendapatan,
                backgroundColor: 'rgba(37, 99, 235, 0.7)',
                borderColor: 'rgba(37, 99, 235, 1)',
                borderWidth: 1,
                borderRadius: 5
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    title: {
                        display: true,
                        text: 'Total Pendapatan (Rp)'
                    },
                    ticks: {
                        callback: function(value) {
                            return 'Rp ' + value.toLocaleString('id-ID');
                        }
                    }
                },
                x: {
                    title: {
                        display: true,
                        text: 'Tanggal Transaksi'
                    }
                }
            }
        }
    });
</script>
<?php endif; ?>
</body>
</html>
