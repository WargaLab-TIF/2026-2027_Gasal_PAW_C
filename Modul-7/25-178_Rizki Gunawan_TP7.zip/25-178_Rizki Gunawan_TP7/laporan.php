<?php
require_once 'koneksi.php';
$tgl_mulai   = $_GET['tanggal_mulai'] ?? '';
$tgl_selesai = $_GET['tanggal_selesai'] ?? '';
$labels           = [];
$data_pendapatan  = [];
$rekap_harian     = [];
$total_pelanggan  = 0;
$total_pendapatan = 0;
if (!empty($tgl_mulai) && !empty($tgl_selesai)) {
    $mulai_safe   = mysqli_real_escape_string($koneksi, $tgl_mulai);
    $selesai_safe = mysqli_real_escape_string($koneksi, $tgl_selesai);
    $query_rekap = "SELECT 
                        DATE(waktu_transaksi) AS tanggal, 
                        SUM(total) AS total_harian 
                    FROM transaksi 
                    WHERE DATE(waktu_transaksi) BETWEEN '$mulai_safe' AND '$selesai_safe' 
                    GROUP BY DATE(waktu_transaksi) 
                    ORDER BY tanggal ASC";
    $result_rekap = mysqli_query($koneksi, $query_rekap);
    while ($row = mysqli_fetch_assoc($result_rekap)) {
        $labels[]          = $row['tanggal'];
        $data_pendapatan[] = (int)$row['total_harian'];
        $rekap_harian[]    = $row;
        $total_pendapatan += (int)$row['total_harian'];
    }
    $query_pelanggan = "SELECT 
                            COUNT(DISTINCT pelanggan_id) AS jml_pelanggan 
                        FROM transaksi 
                        WHERE DATE(waktu_transaksi) BETWEEN '$mulai_safe' AND '$selesai_safe'";
    $result_pelanggan = mysqli_query($koneksi, $query_pelanggan);
    $row_pelanggan    = mysqli_fetch_assoc($result_pelanggan);
    $total_pelanggan  = $row_pelanggan['jml_pelanggan'] ?? 0;
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Laporan Penjualan</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; color: #000; background: #fff; }
        h2 { margin-bottom: 5px; }
        form { margin-bottom: 20px; }
        table { width: 100%; border-collapse: collapse; margin-top: 15px; margin-bottom: 15px; }
        th, td { border: 1px solid #000; padding: 6px; text-align: left; }
        th { background-color: #f2f2f2; }
        .summary-box { margin-top: 15px; padding: 10px; border: 1px solid #000; display: inline-block; width: 100%; box-sizing: border-box; }
        @media print {
            .no-print { display: none !important; }
        }
    </style>
</head>
<body>
    <h2>Rekap Laporan Penjualan</h2>
    <form method="GET" action="" class="no-print">
        Dari: <input type="date" name="tanggal_mulai" value="<?= htmlspecialchars($tgl_mulai); ?>" required>
        Sampai: <input type="date" name="tanggal_selesai" value="<?= htmlspecialchars($tgl_selesai); ?>" required>
        <button type="submit">Tampilkan</button>
    </form>
    <?php if (!empty($tgl_mulai) && !empty($tgl_selesai)): ?>
        <?php if (count($rekap_harian) > 0): ?>
            <div class="no-print" style="margin-bottom: 20px;">
                <button onclick="window.print()">Cetak</button>
                <a href="export_excel.php?tanggal_mulai=<?= urlencode($tgl_mulai); ?>&tanggal_selesai=<?= urlencode($tgl_selesai); ?>"><button type="button">Excel</button></a>
            </div>
            <div style="width: 600px; height: 300px; margin-bottom: 30px;">
                <canvas id="myChart"></canvas>
            </div>
            <table>
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Total Pendapatan</th>
                        <th>Tanggal Transaksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $no = 1; foreach ($rekap_harian as $row): ?>
                        <tr>
                            <td><?= $no++; ?></td>
                            <td>Rp. <?= number_format($row['total_harian'], 0, ',', '.'); ?></td>
                            <td><?= $row['tanggal']; ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <div class="summary-box">
                <p><b>Jumlah Pelanggan:</b> <?= $total_pelanggan; ?> Orang | <b>Jumlah Pendapatan:</b> Rp. <?= number_format($total_pendapatan, 0, ',', '.'); ?></p>
            </div>
            <script>
                const ctx = document.getElementById('myChart').getContext('2d');
                new Chart(ctx, {
                    type: 'bar',
                    data: {
                        labels: <?= json_encode($labels); ?>,
                        datasets: [{
                            label: 'Total Penjualan',
                            data: <?= json_encode($data_pendapatan); ?>,
                            backgroundColor: '#cccccc'
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false
                    }
                });
            </script>
        <?php else: ?>
            <p>Tidak ada data pada rentang tanggal tersebut.</p>
        <?php endif; ?>
    <?php endif; ?>
</body>
</html>