<?php
include 'koneksi.php';
$tanggal_mulai = $_GET['tanggal_mulai'] ?? '';
$tanggal_selesai = $_GET['tanggal_selesai'] ?? '';
$data = [];
if ($tanggal_mulai != '' && $tanggal_selesai != '') {
    $query = "SELECT waktu_transaksi, SUM(total) AS total_pendapatan
              FROM transaksi
              WHERE waktu_transaksi BETWEEN '$tanggal_mulai' AND '$tanggal_selesai'
              GROUP BY waktu_transaksi
              ORDER BY waktu_transaksi ASC";
    $result = mysqli_query($koneksi, $query);
    while ($row = mysqli_fetch_assoc($result)) {
        $data[] = $row;
    }
    $query2 = "SELECT
                COUNT(DISTINCT pelanggan_id) AS jumlah_pelanggan,
                SUM(total) AS total_pendapatan
               FROM transaksi
               WHERE waktu_transaksi BETWEEN '$tanggal_mulai' AND '$tanggal_selesai'";
    $result2 = mysqli_query($koneksi, $query2);
    $ringkasan = mysqli_fetch_assoc($result2);
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Laporan Penjualan</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
<h2>Laporan Penjualan</h2>
<form method="GET">
    Tanggal Mulai:
    <input type="date" name="tanggal_mulai"
    value="<?php echo htmlspecialchars($tanggal_mulai); ?>" required>
    Tanggal Selesai:
    <input type="date" name="tanggal_selesai"
    value="<?php echo htmlspecialchars($tanggal_selesai); ?>" required>
    <button type="submit">Tampilkan</button>
</form>
<?php if ($tanggal_mulai != '' && $tanggal_selesai != ''): ?>
    <br>
    <button onclick="window.print()">Cetak</button>
    <a href="export_excel.php?tanggal_mulai=<?php echo urlencode($tanggal_mulai); ?>&tanggal_selesai=<?php echo urlencode($tanggal_selesai); ?>">
        <button type="button">Export Excel</button>
    </a>
    <h3>Grafik Penjualan Harian</h3>
    <canvas id="grafik" width="600" height="250"></canvas>
    <script>
        new Chart(document.getElementById('grafik'), {
            type: 'bar',
            data: {
                labels: <?php echo json_encode(array_column($data, 'waktu_transaksi')); ?>,
                datasets: [{
                    label: 'Total Pendapatan',
                    data: <?php echo json_encode(array_column($data, 'total_pendapatan')); ?>,
                    backgroundColor: 'blue'
                }]
            }
        });
    </script>
    <h3>Rekapitulasi Penjualan Harian</h3>
    <table border="1" cellpadding="8">
        <tr>
            <th>No</th>
            <th>Total Pendapatan</th>
            <th>Tanggal Transaksi</th>
        </tr>
        <?php $no = 1; ?>
        <?php foreach ($data as $row): ?>
        <tr>
            <td><?php echo $no++; ?></td>
            <td>
                Rp <?php echo number_format($row['total_pendapatan'], 0, ',', '.'); ?>
            </td>
            <td><?php echo $row['waktu_transaksi']; ?></td>
        </tr>
        <?php endforeach; ?>
    </table>
    <h3>Ringkasan Penjualan</h3>
    <p>
        Jumlah Pelanggan Unik:
        <?php echo $ringkasan['jumlah_pelanggan']; ?>
    </p>
    <p>
        Total Pendapatan:
        Rp <?php echo number_format($ringkasan['total_pendapatan'] ?? 0, 0, ',', '.'); ?>
    </p>
<?php endif; ?>
<style>
@media print {
    form, button, a {
        display: none;
    }
}
</style>
</body>
</html>